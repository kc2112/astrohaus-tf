export const handler = async event => {

    return {
        domain: "kc2112.com",
        data: "123123123"
    }
};